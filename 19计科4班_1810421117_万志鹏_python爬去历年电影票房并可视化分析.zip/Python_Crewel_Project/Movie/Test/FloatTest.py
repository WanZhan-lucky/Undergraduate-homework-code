#-*- coding = utf-8 -*-
#@Time : 2021/11/7 17:20
#@Author : 万战
#@File : FloatTest.py
#@Software : PyCharm

s = "-"
print(float(s))
# fmovie = open("movie2001-2021.csv", mode='w', encoding = "utf-8")
# listk = ['序列', '年份', '电影', '票房(万元)']
# for t in range(len(listk)):
#     fmovie.write(listk[t])
#     fmovie.write(",")
# fmovie.write("\n")

#
# import re
# pat = re.compile(r'(.*)（总计）')
# fmovie = open("./year_movie-utf8.csv", "w",newline='', encoding = 'utf-8')
# writer = csv.writer(fmovie)